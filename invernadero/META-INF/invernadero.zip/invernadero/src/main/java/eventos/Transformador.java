package eventos;

import org.mule.api.annotations.ContainsTransformerMethods;
import org.mule.api.annotations.Transformer;
import org.mule.module.json.JsonData;

import eventos.EventoInvernadero;

@ContainsTransformerMethods
public class Transformador
{
	@Transformer  
	public EventoInvernadero JSONToEventoInvernadero(JsonData obj) throws Exception 
	{	  	  
		EventoInvernadero evento = new EventoInvernadero();
		String nombreInvernadero = obj.getAsString("channel/name");
		
		if(nombreInvernadero.equalsIgnoreCase("Osterloh Greenhouse")) {
			evento.setHora(obj.getAsString("feeds[1]/created_at")); 
			evento.setTempAgua(Float.parseFloat(obj.getAsString("feeds[1]/field1")));
			evento.setTempInt(Float.parseFloat(obj.getAsString("feeds[1]/field2")));
			evento.setTempExt(Float.parseFloat(obj.getAsString("feeds[1]/field4")));
			evento.setPH(Float.parseFloat(obj.getAsString("feeds[1]/field5")));
			System.out.println("Evento transformado: " + evento);
		}
		else {
			System.out.println("No es posible realizar la conversión");
		}
		
		return evento; 
	}
}