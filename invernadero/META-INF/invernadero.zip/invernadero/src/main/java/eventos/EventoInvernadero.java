package eventos;

public class EventoInvernadero {	
	
	private String hora;
	private float temperaturaAgua; 
	private float temperaturaInterior; 
	private float temperaturaExterior; 
	private float pH;
	
	public EventoInvernadero(String h, float tA, float tI, float tE, float pph) {
		hora = h;
		temperaturaAgua = tA;
		temperaturaInterior = tI;
		temperaturaExterior = tE;
		pH = pph;
	}
		
	public EventoInvernadero() {
		
	}

	public String getHora() {
		return hora;
	}
	
	public float getTempAgua() {
		return temperaturaAgua;
	}

	public float getTempInt() {
		return temperaturaInterior;
	}

	public float getTempExt() {
		return temperaturaExterior;
	}

	public float getPH() {
		return pH;
	}

	public void setHora(String h) {
		hora = h;
	}
	
	public void setTempAgua(float tA) {
		temperaturaAgua = tA; 
	}

	public void setTempInt(float tI) {
		temperaturaInterior = tI; 
	}

	public void setTempExt(float tE) {
		temperaturaExterior = tE; 
	}

	public void setPH(float pph) {
		pH = pph; 
	}

	@Override
	public String toString() {
		return "Fecha:  " + hora + "\n - Temperatura del agua=" + temperaturaAgua
				+ "\n - Temperatura Interior=" + temperaturaInterior 
				+ "\n - Temperatura Exterior=" + temperaturaExterior
				+ "\n - pH=" + pH
				+ "\n";
	}
}